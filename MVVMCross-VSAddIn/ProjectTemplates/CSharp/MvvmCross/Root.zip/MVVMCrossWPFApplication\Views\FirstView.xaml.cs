using MvvmCross.Wpf.Views;

namespace $safeprojectname$.Views
{
    public partial class FirstView : MvxWpfView
    {
        public FirstView()
        {
            this.InitializeComponent();
        }
    }
}
