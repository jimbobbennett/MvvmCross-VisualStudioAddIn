using MvvmCross.WindowsCommon.Views;

namespace $safeprojectname$.Views
{
    public sealed partial class FirstView : MvxWindowsPage
    {
        public FirstView()
        {
            this.InitializeComponent();
        }
    }
}
