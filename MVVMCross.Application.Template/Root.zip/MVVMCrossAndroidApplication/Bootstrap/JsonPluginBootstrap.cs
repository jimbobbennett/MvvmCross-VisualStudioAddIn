using MvvmCross.Platform.Plugins;

namespace $safeprojectname$
{
    public class JsonPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Json.PluginLoader>
    {
    }
}
